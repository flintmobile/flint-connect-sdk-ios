//
//  FlintConnectUI.h
//  FlintConnect
//
//  Created by PC on 1/13/16.
//  Copyright © 2016 Flint. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FlintHeaderImport.h"
#import "FlintUI.h"

@interface FlintConnectUI : NSObject

@end
