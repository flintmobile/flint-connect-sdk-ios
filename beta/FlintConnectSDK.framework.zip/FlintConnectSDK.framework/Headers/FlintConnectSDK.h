//
//  FlintConnectSDK.h
//  FlintConnect
//
//  Created by PC on 9/3/15.
//  Copyright (c) 2015 Flint. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "FlintHeaderImport.h"
#import "FlintUI.h"

@interface FlintConnectSDK : NSObject

@end
