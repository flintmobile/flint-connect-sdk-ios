//
//  FlintResources.h
//  FlintConnect
//
//  Created by PC on 3/11/15.
//  Copyright (c) 2015 Flint. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FlintResources : NSObject

@property (strong, nonatomic) NSBundle *resourceBundle;

+ (instancetype)sharedInstance;

@end
