//
/*! @file FlintEmailEntryView.h */
//  FlintConnect
//
//  Created by Phuoc Nguyen on 8/14/15.
//  Copyright (c) 2015 Flint. All rights reserved.
//

#import "FlintTextEntryView.h"

@class FlintLineTextField;

IB_DESIGNABLE

@interface FlintEmailEntryView : FlintTextEntryView

@end