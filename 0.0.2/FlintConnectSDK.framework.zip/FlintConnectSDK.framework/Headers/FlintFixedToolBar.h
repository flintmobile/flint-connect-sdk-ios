//
//  FlintFixedToolBar.h
//  FlintCardScanner
//
//  Created by PC on 11/30/15.
//  Copyright © 2015 Flint Mobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlintFixedToolBar : UIToolbar

@end
